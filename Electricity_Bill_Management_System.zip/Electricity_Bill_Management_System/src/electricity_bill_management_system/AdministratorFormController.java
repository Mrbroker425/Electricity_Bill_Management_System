/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

public class AdministratorFormController implements Initializable {

    @FXML
    private Label GeneratedBills;
    @FXML
    private Label TotalPendingBills;

    @FXML
    private Label TotalTransactions;

    @FXML
    private Label UnprocessedComplaints;

    @FXML
    private TableView<Customer> customerTableViews;

    @FXML
    private TableColumn<Customer, Integer> CustomerID;

    @FXML
    private TableColumn<Customer, String> CustomerUsername;

    @FXML
    private TableColumn<Customer, String> Contact;

    @FXML
    private TableColumn<Customer, String> Password;

    @FXML
    private TableColumn<Customer, String> Role;

    private ObservableList<Customer> customerData;

    @FXML
    private TableColumn<Bill, Double> admin_Amount;

    @FXML
    private TableColumn<Bill, String> admin_Billno;

    @FXML
    private TableColumn<Bill, String> admin_Customer;

    @FXML
    private TableColumn<Bill, String> adminBill_Status;

    @FXML
    private TableColumn<Bill, LocalDate> admin_BillDate;

    @FXML
    private TableColumn<Bill, LocalDate> admin_DueDate;

    @FXML
    private TableColumn<Bill, Integer> admin_UnitsConsumed;

    @FXML
    private TextField adminUnitsConsumed;

    @FXML
    private DatePicker adminDueDate;

    @FXML
    private ComboBox<String> StatusListProcess;

    @FXML
    private AnchorPane GenerateBillPane;

    @FXML
    private TableView<Bill> adminBillTableView;

    @FXML
    private TableColumn<CustomerComplaint, String> admin_Complaint;

    @FXML
    private TableColumn<CustomerComplaint, String> admin_ComplaintDate;

    @FXML
    private TableColumn<CustomerComplaint, String> admin_ComplaintIDno;

    @FXML
    private TableView<CustomerComplaint> admin_ComplaintsHistorytableViews;

    @FXML
    private TableColumn<CustomerComplaint, String> admin_CustomerUsername;

    @FXML
    private ComboBox<String> admin_ProcessComplaints;

    @FXML
    private TableColumn<CustomerComplaint, String> admin_Status;

    @FXML
    private AnchorPane AdminBillPane;

    @FXML
    private Button AdminBillings;

    @FXML
    private Button AdminComplaints;

    @FXML
    private AnchorPane AdminComplaintsDashboardPane;

    @FXML
    private AnchorPane AdminComplaintsPane;

    @FXML
    private Button AdminCustomer;

    @FXML
    private AnchorPane AdminCustomerPane;

    @FXML
    private Button GenerateNewBillbtn;

    @FXML
    private Button AdminDashboard;

    @FXML
    private FontAwesomeIcon Closebtn;

    private SystemData systemData = new SystemData(1);

    public void roleList() {
        List<String> listR = new ArrayList<>();
        listR.add("Resolved");
        listR.add("In Progress");
        listR.add("Acknowledged");

        ObservableList<String> listData = FXCollections.observableArrayList(listR);
        admin_ProcessComplaints.setItems(listData);
    }

    public void StatusList() {
        List<String> listR = new ArrayList<>();
        listR.add("Awaiting Payment");
        listR.add("Pending Payement");
        listR.add("Paid");

        ObservableList<String> listData = FXCollections.observableArrayList(listR);
        StatusListProcess.setItems(listData);
    }

    @FXML
    private void switchForms(ActionEvent event) {
        // First, hide all other panes
        hideAllPanes();

        // Check which button was clicked
        if (event.getSource() == AdminDashboard) {
            // Disable the clicked button to prevent multiple clicks
            AdminDashboard.setDisable(true);

            // Make the corresponding pane visible
            if (AdminComplaintsDashboardPane != null) {
                AdminComplaintsDashboardPane.setVisible(true);
            }

            // Enable other buttons as needed
            AdminBillings.setDisable(false);
            AdminComplaints.setDisable(false);
            AdminCustomer.setDisable(false);
        } else if (event.getSource() == AdminBillings) {
            // Disable the clicked button to prevent multiple clicks
            AdminBillings.setDisable(true);

            // Make the corresponding pane visible
            if (AdminBillPane != null) {
                AdminBillPane.setVisible(true);
            }

            // Enable other buttons as needed
            AdminDashboard.setDisable(false);
            AdminComplaints.setDisable(false);
            AdminCustomer.setDisable(false);
        } else if (event.getSource() == AdminComplaints) {
            // Disable the clicked button to prevent multiple clicks
            AdminComplaints.setDisable(true);

            // Make the corresponding pane visible
            if (AdminComplaintsPane != null) {
                AdminComplaintsPane.setVisible(true);
            }

            // Enable other buttons as needed
            AdminDashboard.setDisable(false);
            AdminBillings.setDisable(false);
            AdminCustomer.setDisable(false);

            // Load the customer complaints
            updateAdminComplaintsTableView();
        } else if (event.getSource() == AdminCustomer) {
            // Disable the clicked button to prevent multiple clicks
            AdminCustomer.setDisable(true);

            // Make the corresponding pane visible
            if (AdminCustomerPane != null) {
                AdminCustomerPane.setVisible(true);
            }

            // Enable other buttons as needed
            AdminDashboard.setDisable(false);
            AdminBillings.setDisable(false);
            AdminComplaints.setDisable(false);
        }
    }

    private void hideAllPanes() {
        // Hide all panes
        if (AdminBillPane != null) {
            AdminBillPane.setVisible(false);
        }
        if (AdminComplaintsDashboardPane != null) {
            AdminComplaintsDashboardPane.setVisible(false);
        }
        if (AdminComplaintsPane != null) {
            AdminComplaintsPane.setVisible(false);
        }
        if (AdminCustomerPane != null) {
            AdminCustomerPane.setVisible(false);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set up the TableView columns
        admin_Complaint.setCellValueFactory(new PropertyValueFactory<>("customerComplaint"));
        admin_ComplaintDate.setCellValueFactory(new PropertyValueFactory<>("customerComplaintDate"));
        admin_ComplaintIDno.setCellValueFactory(new PropertyValueFactory<>("customerComplaintIDno"));
        admin_CustomerUsername.setCellValueFactory(new PropertyValueFactory<>("customerUsername"));
        admin_Status.setCellValueFactory(new PropertyValueFactory<>("customerStatus"));

        // Set up the TableView columns for the bills
        admin_Billno.setCellValueFactory(new PropertyValueFactory<>("billNo"));
        admin_Customer.setCellValueFactory(new PropertyValueFactory<>("customer"));
        admin_BillDate.setCellValueFactory(new PropertyValueFactory<>("billDate"));
        admin_UnitsConsumed.setCellValueFactory(new PropertyValueFactory<>("unitsConsumed"));
        admin_Amount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        admin_DueDate.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        adminBill_Status.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Set up the TableView columns for the customers
        CustomerID.setCellValueFactory(new PropertyValueFactory<>("customer_id"));
        CustomerUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        Contact.setCellValueFactory(new PropertyValueFactory<>("contact"));
        Password.setCellValueFactory(new PropertyValueFactory<>("password"));
        Role.setCellValueFactory(new PropertyValueFactory<>("role"));

        // Load the customer data
        loadCustomerData();
        // Update the labels
        updateLabels();
        // Populate the admin_ProcessComplaints ComboBox
        roleList();
        StatusList();
        Popup();

        // Set up the event listener for the admin_ProcessComplaints ComboBox
        admin_ProcessComplaints.setOnAction(this::handleStatusChange);

        // Set up the event handler for the "Generate New Bill" button
        GenerateNewBillbtn.setOnAction(this::generateNewBill);

        // Initialize the SystemData instance
        systemData = new SystemData(1);

        // Populate the adminBillTableView
        populateAdminBillTableView();
    }

    private void loadCustomerData() {
        // Retrieve the customer data from the SystemData class
        customerData = systemData.getAllCustomers();

        // Set the items of the TableView
        customerTableViews.setItems(customerData);
    }

    @FXML
    private void updateCustomerTable(ActionEvent event) {
        // Refresh the customer table
        loadCustomerData();
    }

    @FXML
    private void showGenerateBillPane(ActionEvent event) {
        GenerateBillPane.setVisible(true);
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private String generateBillNumber() {
        // Retrieve the last bill number from the database
        String lastBillNumberStr = systemData.getLastBillNumber();

        // Generate the next bill number
        int lastBillNumber = 0;
        if (lastBillNumberStr != null && !lastBillNumberStr.isEmpty()) {
            lastBillNumber = Integer.parseInt(lastBillNumberStr.substring(1));
        }
        int nextBillNumber = lastBillNumber + 1;

        // Convert the next bill number to a string and pad it with leading zeros if necessary
        return String.format("B%06d", nextBillNumber);
    }

    private String calculateAmount(int unitsConsumed) {
        // Define the base rate per unit
        double baseRatePerUnit = 2.5; // Example base rate per unit

        // Define the minimum and maximum multiplier factors
        double minMultiplier = 0.8; // Example minimum multiplier factor
        double maxMultiplier = 1.2; // Example maximum multiplier factor

        // Calculate the minimum and maximum amounts
        double minAmount = unitsConsumed * baseRatePerUnit * minMultiplier;
        double maxAmount = unitsConsumed * baseRatePerUnit * maxMultiplier;

        // Generate a random amount within the range
        double randomAmount = minAmount + (maxAmount - minAmount) * Math.random();

        // Round the amount to the nearest 100 (e.g., R4,000, R12,000)
        double roundedAmount = Math.round(randomAmount / 100.0) * 100.0;

        // Format the amount with the 'R' prefix and commas
        return "R" + String.format("%,.0f", roundedAmount);
    }

    @FXML
    private void generateBill(ActionEvent event) {
        // Check if the user has entered valid input
        if (validateBillInput()) {
            String billNo = generateBillNumber();
            String customer = systemData.getLoggedInCustomerUsername();
            LocalDate billDate = LocalDate.now();

            int unitsConsumed = Integer.parseInt(adminUnitsConsumed.getText());
            String amountStr = calculateAmount(unitsConsumed);
            double amount = Double.parseDouble(amountStr.substring(1).replace(",", ""));

            LocalDate dueDate = adminDueDate.getValue();
            String status = StatusListProcess.getSelectionModel().getSelectedItem();

            Bill newBill = new Bill(billNo, customer, billDate, unitsConsumed, amount, dueDate, status);
            addBillToTable(newBill);
            systemData.saveBill(newBill);
            populateAdminBillTableView(); // Populate the table view after adding the new bill
            GenerateBillPane.setVisible(false); // Hide the GenerateBillPane after generating the bill
        }
    }

    @FXML
    private void handleStatusChange(ActionEvent event) {
        CustomerComplaint selectedComplaint = admin_ComplaintsHistorytableViews.getSelectionModel().getSelectedItem();
        if (selectedComplaint != null) {
            String newStatus = admin_ProcessComplaints.getSelectionModel().getSelectedItem();
            if (newStatus != null) {
                systemData.updateComplaintStatus(selectedComplaint.getCustomerComplaintIDno(), newStatus);
                selectedComplaint.setCustomerStatus(newStatus);
                admin_ComplaintsHistorytableViews.refresh();
            } else {
                showErrorMessage("Please select a status to change the complaint.");
            }
        } else {
            showErrorMessage("Please select a complaint to change the status.");
        }
    }

    private void updateAdminComplaintsTableView() {
        ObservableList<CustomerComplaint> customerComplaints = systemData.getAllCustomerComplaints();
        admin_ComplaintsHistorytableViews.setItems(customerComplaints);
    }

    @FXML
    void Popup() {
        GenerateNewBillbtn.setOnAction(this::showGenerateBillPane);
        Closebtn.setOnMouseClicked(event -> GenerateBillPane.setVisible(false));
        GenerateBillPane.setVisible(false);
    }

    @FXML
    private void generateNewBill(ActionEvent event) {
        showGenerateBillPane(event);
    }

    private void addBillToTable(Bill newBill) {
        adminBillTableView.getItems().add(newBill);
    }

    private void populateAdminBillTableView() {
        ObservableList<Bill> bills = systemData.getAllBills();
        adminBillTableView.setItems(bills);
    }

    private boolean validateBillInput() {
        // Check if the user has entered a valid number of units consumed
        try {
            int unitsConsumed = Integer.parseInt(adminUnitsConsumed.getText());
            // Check if the user has selected a due date
            if (adminDueDate.getValue() == null) {
                showErrorMessage("Please select a due date for the bill.");
                return false;
            }
            // Check if the user has selected a status
            if (StatusListProcess.getSelectionModel().getSelectedItem() == null) {
                showErrorMessage("Please select a status for the bill.");
                return false;
            }
            return true;
        } catch (NumberFormatException e) {
            showErrorMessage("Please enter a valid number of units consumed.");
            return false;
        }
    }

    private void updateLabels() {
        // Get the data from the TableViews
        ObservableList<Bill> bills = systemData.getAllBills();
        ObservableList<CustomerComplaint> complaints = systemData.getAllCustomerComplaints();

        // Calculate the values for the labels
        int generatedBills = 0;
        int pendingBills = 0;
        double totalTransactions = 0.0;
        int unprocessedComplaints = 0;

        for (Bill bill : bills) {
            if (bill.getStatus().equals("Paid")) {
                generatedBills++;
            } else {
                pendingBills++;
            }
            totalTransactions += bill.getAmount();
        }

        for (CustomerComplaint complaint : complaints) {
            if (!complaint.getCustomerStatus().equals("Resolved")) {
                unprocessedComplaints++;
            }
        }

        // Update the labels
        GeneratedBills.setText(String.valueOf(generatedBills));
        TotalPendingBills.setText(String.valueOf(pendingBills));
        TotalTransactions.setText("R" + String.format("%,.2f", totalTransactions));
        UnprocessedComplaints.setText(String.valueOf(unprocessedComplaints));
    }

}
