/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import java.time.LocalDate;

/**
 *
 * @author Admin
 * 
 */

public class Bill {

    private final SimpleStringProperty billNo;
    private final SimpleStringProperty customer;
    private final SimpleObjectProperty<LocalDate> billDate;
    private final SimpleIntegerProperty unitsConsumed;
    private final SimpleDoubleProperty amount;
    private final SimpleObjectProperty<LocalDate> dueDate;
    private final SimpleStringProperty status;

    public Bill(String billNo, String customer, LocalDate billDate, int unitsConsumed, double amount, LocalDate dueDate, String status) {
        this.billNo = new SimpleStringProperty(billNo);
        this.customer = new SimpleStringProperty(customer);
        this.billDate = new SimpleObjectProperty<>(billDate);
        this.unitsConsumed = new SimpleIntegerProperty(unitsConsumed);
        this.amount = new SimpleDoubleProperty(amount);
        this.dueDate = new SimpleObjectProperty<>(dueDate);
        this.status = new SimpleStringProperty(status);
    }

    public String getBillNo() {
        return billNo.get();
    }

    public void setBillNo(String billNo) {
        this.billNo.set(billNo);
    }

    public String getCustomer() {
        return customer.get();
    }

    public void setCustomer(String customer) {
        this.customer.set(customer);
    }

    public LocalDate getBillDate() {
        return billDate.get();
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate.set(billDate);
    }

    public int getUnitsConsumed() {
        return unitsConsumed.get();
    }

    public void setUnitsConsumed(int unitsConsumed) {
        this.unitsConsumed.set(unitsConsumed);
    }

    public double getAmount() {
        return amount.get();
    }

    public void setAmount(double amount) {
        this.amount.set(amount);
    }

    public LocalDate getDueDate() {
        return dueDate.get();
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate.set(dueDate);
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }
}
