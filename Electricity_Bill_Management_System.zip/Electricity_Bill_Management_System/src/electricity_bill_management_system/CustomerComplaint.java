/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Admin
 */
public class CustomerComplaint {

    private final StringProperty customerComplaint;
    private final StringProperty customerComplaintDate;
    private final StringProperty customerComplaintIDno;
    private final StringProperty customerUsername;
    private final StringProperty customerStatus;

    public CustomerComplaint(String customerComplaint, String customerComplaintDate, String customerComplaintIDno, String customerUsername, String customerStatus) {
        this.customerComplaint = new SimpleStringProperty(customerComplaint);
        this.customerComplaintDate = new SimpleStringProperty(customerComplaintDate);
        this.customerComplaintIDno = new SimpleStringProperty(customerComplaintIDno);
        this.customerUsername = new SimpleStringProperty(customerUsername);
        this.customerStatus = new SimpleStringProperty(customerStatus);
    }

    public String getCustomerComplaint() {
        return customerComplaint.get();
    }

    public StringProperty customerComplaintProperty() {
        return customerComplaint;
    }

    public String getCustomerComplaintDate() {
        return customerComplaintDate.get();
    }

    public StringProperty customerComplaintDateProperty() {
        return customerComplaintDate;
    }

    public String getCustomerComplaintIDno() {
        return customerComplaintIDno.get();
    }

    public StringProperty customerComplaintIDnoProperty() {
        return customerComplaintIDno;
    }

    public String getCustomerUsername() {
        return customerUsername.get();
    }

    public StringProperty customerUsernameProperty() {
        return customerUsername;
    }

    public String getCustomerStatus() {
        return customerStatus.get();
    }

    public StringProperty customerStatusProperty() {
        return customerStatus;
    }

    public void setCustomerStatus(String status) {
        this.customerStatus.set(status);
    }
}
