/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class CustomerController implements Initializable {

    @FXML
    private Label CheckinAdmins;
    @FXML
    private FontAwesomeIcon recoderSound;
    @FXML
    private Label PaidBills;

    @FXML
    private Label PendingBills;

    @FXML
    private Hyperlink Customer_hyperlink11;

    @FXML
    private Hyperlink Customer_hyperlink12;

    @FXML
    private Hyperlink Customer_hyperlink13;

    @FXML
    private Hyperlink Customer_hyperlink14;

    @FXML
    private Hyperlink Customer_hyperlink15;
    @FXML
    private TableColumn<Bill, String> Customers_Billno;

    @FXML
    private TableColumn<Bill, String> Customers_Customer;

    @FXML
    private TableColumn<Bill, LocalDate> Customers_BillDate;

    @FXML
    private TableColumn<Bill, Integer> Customers_UnitsConsumed;

    @FXML
    private TableColumn<Bill, Double> CustomersAmounts_AmountOwed;

    @FXML
    private TableColumn<Bill, LocalDate> Customers_DueDate;

    @FXML
    private TableColumn<Bill, String> Customers_Status;

    @FXML
    private TableView<Bill> CustomersBillTableView;

    //////////////////////////////////////////////////////////////
    @FXML
    private AnchorPane CustomerBillsDashboardPane;

    @FXML
    private Button CustomerBillsDashboardbtn;

    @FXML
    private AnchorPane CustomerComplaintsDashboardPane;

    @FXML
    private Button CustomerComplaintsDashboardbtn;

    @FXML
    private AnchorPane CustomerDashboardPane;

    @FXML
    private Button CustomerDashboardbtn;

    @FXML
    private AnchorPane CustomerTransactionsDashboardPane;

    @FXML
    private Button CustomerTransactionsDashboardbtn;

    @FXML
    private TableColumn<CustomerComplaint, String> Customer_Complaint;

    @FXML
    private TableColumn<CustomerComplaint, String> Customer_ComplaintDate;

    @FXML
    private TableColumn<CustomerComplaint, String> Customer_ComplaintIDno;

    @FXML
    private TableView<CustomerComplaint> Customer_ComplaintsHistorytableViews;

    @FXML
    private TableColumn<CustomerComplaint, String> Customer_CustomerUsername;

    @FXML
    private TableColumn<CustomerComplaint, String> Customer_Status;

    @FXML
    private Label Customer_UnprocessedComplaintsUpdate;

    @FXML
    private ComboBox<String> NewComplaintSelect;
    @FXML
    private ComboBox<String> CustomerPaymentOptions;

    private final SystemData systemData = new SystemData(1); // Replace 1 with the logged-in customer's ID

    @FXML
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // Check if the FXML elements are properly injected
            if (Customer_Complaint != null && Customer_ComplaintDate != null && Customer_ComplaintIDno != null && Customer_CustomerUsername != null && Customer_Status != null && NewComplaintSelect != null) {
                // Set up the TableView columns for the customer bills
                Customers_Billno.setCellValueFactory(new PropertyValueFactory<>("billNo"));
                Customers_Customer.setCellValueFactory(new PropertyValueFactory<>("customer"));
                Customers_BillDate.setCellValueFactory(new PropertyValueFactory<>("billDate"));
                Customers_UnitsConsumed.setCellValueFactory(new PropertyValueFactory<>("unitsConsumed"));
                CustomersAmounts_AmountOwed.setCellValueFactory(new PropertyValueFactory<>("amount"));
                Customers_DueDate.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
                Customers_Status.setCellValueFactory(new PropertyValueFactory<>("status"));

                // Set up the TableView columns for the customer complaints
                Customer_Complaint.setCellValueFactory(new PropertyValueFactory<>("customerComplaint"));
                Customer_ComplaintDate.setCellValueFactory(new PropertyValueFactory<>("customerComplaintDate"));
                Customer_ComplaintIDno.setCellValueFactory(new PropertyValueFactory<>("customerComplaintIDno"));
                Customer_CustomerUsername.setCellValueFactory(new PropertyValueFactory<>("customerUsername"));
                Customer_Status.setCellValueFactory(new PropertyValueFactory<>("customerStatus"));

                // Handle click events for each hyperlink
                Customer_hyperlink11.setOnAction(event -> openWebsite("https://openlibrary.org/"));
                Customer_hyperlink12.setOnAction(event -> openWebsite("https://bestenergysavers.shop/en-b/?ref_id=bead8cf29c86128a086beacc678deb4c&msclkid=bead8cf29c86128a086beacc678deb4c"));
                Customer_hyperlink13.setOnAction(event -> openWebsite("https://www.energy.gov/energysaver/energy-saver-guide-tips-saving-money-and-energy-home"));
                Customer_hyperlink14.setOnAction(event -> openWebsite("https://www.khanacademy.org/"));
                Customer_hyperlink15.setOnAction(event -> openWebsite("https://kahoot.it/"));

                // Populate the NewComplaintSelect ComboBox
                NewComplaintSelect.setItems(systemData.getNewComplaintOptions());

                // Populate the TableView with existing customer complaints
                updateCustomerComplaintsTableView();

                // Populate the CustomerPaymentOptions ComboBox
                PaymentList();

                // Populate the CustomersBillTableView
                populateCustomerBillTableView();

                // Update the PaidBills and PendingBills labels
                updatePaidAndPendingBillsLabels();
            } else {
                // Handle the case where the FXML elements are not properly injected
                handleFXMLElementsNotInjected();
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }
// Method to open a website in the default browser

    private void openWebsite(String url) {
        try {
            java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
        } catch (java.io.IOException e) {
            System.out.println("Error opening website: " + e.getMessage());
        }
    }

    @FXML
    private void populateCustomerBillTableView() {
        // Retrieve the list of bills for the logged-in customer
        ObservableList<Bill> customerBills = systemData.getCustomerBills(systemData.getLoggedInCustomerUsername());

        // Set the items in the CustomersBillTableView
        CustomersBillTableView.setItems(customerBills);
    }

    public void PaymentList() {
        List<String> listR = new ArrayList<>();
        listR.add("Will Pay Soon");
        listR.add("Waiting for Complaint Response");
        listR.add("Paid");

        ObservableList<String> listData = FXCollections.observableArrayList(listR);
        CustomerPaymentOptions.setItems(listData);
    }

    private void handleFXMLElementsNotInjected() {
        try {
            // Create the TableView and its columns programmatically
            Customer_ComplaintsHistorytableViews = new TableView<>();
            TableColumn<CustomerComplaint, String> complaintColumn = new TableColumn<>("Complaint");
            TableColumn<CustomerComplaint, String> complaintDateColumn = new TableColumn<>("Complaint Date");
            TableColumn<CustomerComplaint, String> complaintIDColumn = new TableColumn<>("Complaint ID");
            TableColumn<CustomerComplaint, String> customerUsernameColumn = new TableColumn<>("Customer Username");
            TableColumn<CustomerComplaint, String> complaintStatusColumn = new TableColumn<>("Complaint Status");

            complaintColumn.setCellValueFactory(new PropertyValueFactory<>("customerComplaint"));
            complaintDateColumn.setCellValueFactory(new PropertyValueFactory<>("customerComplaintDate"));
            complaintIDColumn.setCellValueFactory(new PropertyValueFactory<>("customerComplaintIDno"));
            customerUsernameColumn.setCellValueFactory(new PropertyValueFactory<>("customerUsername"));
            complaintStatusColumn.setCellValueFactory(new PropertyValueFactory<>("customerStatus"));

            Customer_ComplaintsHistorytableViews.getColumns().addAll(complaintColumn, complaintDateColumn, complaintIDColumn, customerUsernameColumn, complaintStatusColumn);

            // Create the ComboBox programmatically
            NewComplaintSelect = new ComboBox<>();
            NewComplaintSelect.setItems(systemData.getNewComplaintOptions());

            // Add the UI elements to the scene or layout
            CustomerDashboardPane.getChildren().add(Customer_ComplaintsHistorytableViews);
            CustomerDashboardPane.getChildren().add(NewComplaintSelect);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    @FXML
    private void handleNewComplaintSelection() {
        String selectedComplaint = NewComplaintSelect.getSelectionModel().getSelectedItem();
        if (selectedComplaint != null) {
            systemData.addCustomerComplaint(selectedComplaint);
            updateCustomerComplaintsTableView();
        }
    }

    private void updateCustomerComplaintsTableView() {
        // Retrieve the list of customer complaints from the SystemData class
        ObservableList<CustomerComplaint> customerComplaints = systemData.getCustomerComplaints();

        // Update the TableView with the new data
        Customer_ComplaintsHistorytableViews.setItems(customerComplaints);

        // Count the number of unprocessed complaints
        long unprocessedComplaints = customerComplaints.stream()
                .filter(c -> c.getCustomerStatus().equals("Open"))
                .count();

        // Update the Customer_UnprocessedComplaintsUpdate label
        Customer_UnprocessedComplaintsUpdate.setText(String.valueOf(unprocessedComplaints));
    }

    @FXML
    private void handlePaymentStatusChange(ActionEvent event) {
        Bill selectedBill = CustomersBillTableView.getSelectionModel().getSelectedItem();
        if (selectedBill != null) {
            String newStatus = CustomerPaymentOptions.getSelectionModel().getSelectedItem();
            if (newStatus != null) {
                systemData.updateBillStatus(selectedBill.getBillNo(), newStatus);
                selectedBill.setStatus(newStatus);
                CustomersBillTableView.refresh();
                updatePaidAndPendingBillsLabels();
            } else {
                showErrorMessage("Please select a status to change the bill payment status.");
            }
        } else {
            showErrorMessage("Please select a bill to change the payment status.");
        }
    }

    private void updatePaidAndPendingBillsLabels() {
        int paidBills = 0;
        int pendingBills = 0;

        for (Bill bill : systemData.getCustomerBills(systemData.getLoggedInCustomerUsername())) {
            if (bill.getStatus().equalsIgnoreCase("Paid")) {
                paidBills++;
            } else {
                pendingBills++;
            }
        }

        PaidBills.setText(String.valueOf(paidBills));
        PendingBills.setText(String.valueOf(pendingBills));
    }

    private void showErrorMessage(String message) {
        // Implement the logic to show an error message to the user
        // For example, you can use a dialog or a label to display the error message
        System.out.println("Error: " + message);
    }

    @FXML
    private void switchCustomerDashboard(ActionEvent event) {
        // First, hide all other customer panes
        hideAllCustomerPanes();

        // Check which button was clicked
        if (event.getSource() == CustomerDashboardbtn) {
            // Disable the clicked button to prevent multiple clicks
            CustomerDashboardbtn.setDisable(true);

            // Make the corresponding pane visible
            CustomerDashboardPane.setVisible(true);

            // Now you can add any additional logic you need for when the Customer Dashboard is displayed
            // For example, you might want to load data specific to the Customer Dashboard
        } else if (event.getSource() == CustomerBillsDashboardbtn) {
            // Disable the clicked button to prevent multiple clicks
            CustomerBillsDashboardbtn.setDisable(true);

            // Make the corresponding pane visible
            CustomerBillsDashboardPane.setVisible(true);

            // Add logic for handling the Bills Dashboard button if needed
        } else if (event.getSource() == CustomerComplaintsDashboardbtn) {
            // Disable the clicked button to prevent multiple clicks
            CustomerComplaintsDashboardbtn.setDisable(true);

            // Make the corresponding pane visible
            CustomerComplaintsDashboardPane.setVisible(true);

            // Add logic for handling the Complaints Dashboard button if needed
        } else if (event.getSource() == CustomerTransactionsDashboardbtn) {
            // Disable the clicked button to prevent multiple clicks
            CustomerTransactionsDashboardbtn.setDisable(true);

            // Make the corresponding pane visible
            CustomerTransactionsDashboardPane.setVisible(true);

            // Add logic for handling the Transactions Dashboard button if needed
        }
    }

    private void hideAllCustomerPanes() {
        // Reset all buttons to enable them
        CustomerDashboardbtn.setDisable(false);
        CustomerBillsDashboardbtn.setDisable(false);
        CustomerComplaintsDashboardbtn.setDisable(false);
        CustomerTransactionsDashboardbtn.setDisable(false);

        // Hide all panes
        CustomerDashboardPane.setVisible(false);
        CustomerBillsDashboardPane.setVisible(false);
        CustomerComplaintsDashboardPane.setVisible(false);
        CustomerTransactionsDashboardPane.setVisible(false);
    }

    private String[] areaNewsSources = {
        "C:\\Users\\Admin\\Documents\\NetBeansProjects\\Electricity_Bill_Management_System\\src\\Electricity_Bill_Management_System_Music\\0511.MP3"
    };

    private int newAreasUpdated = 1; // Initial number of areas with new updates

    private MediaPlayer currentMediaPlayer;

    @FXML
    private void handleRecoderSoundClick(MouseEvent event) {
        if (currentMediaPlayer == null || !currentMediaPlayer.getStatus().equals(MediaPlayer.Status.PLAYING)) {
            playAudio(areaNewsSources[0]);
        } else {
            stopAudio();
            newAreasUpdated = 0;
            updateCheckInAdminsLabel();
        }
    }

    private void updateCheckInAdminsLabel() {
        if (newAreasUpdated > 0) {
            CheckinAdmins.setText("1 New Area News");
        } else {
            CheckinAdmins.setText("No new Area News");
        }
    }

    private void playAudio(String audioSource) {
        try {
            // Stop the current audio player, if any
            if (currentMediaPlayer != null && currentMediaPlayer.getStatus().equals(MediaPlayer.Status.PLAYING)) {
                currentMediaPlayer.stop();
            }

            Media media = new Media(new File(audioSource).toURI().toString());
            currentMediaPlayer = new MediaPlayer(media);
            currentMediaPlayer.setOnEndOfMedia(() -> {
                // Reset the newAreasUpdated variable when the audio finishes playing
                newAreasUpdated = 0;
                updateCheckInAdminsLabel();
            });
            currentMediaPlayer.play();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error playing audio: " + e.getMessage());
        }
    }

    private void stopAudio() {
        if (currentMediaPlayer != null && currentMediaPlayer.getStatus().equals(MediaPlayer.Status.PLAYING)) {
            currentMediaPlayer.stop();
        }
    }

}
