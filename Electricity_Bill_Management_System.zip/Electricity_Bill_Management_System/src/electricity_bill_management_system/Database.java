/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Admin
 */
public class Database {

    // Method to establish a connection to the MySQL database
    public static Connection getConnection() {
        try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the MySQL database
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/electricity_bill_management_system", "root", "");
            return connection; // Return the Connection object if connection is successful
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace if an exception occurs during connection
        }
        return null; // Return null if connection fails
    }
}
