/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

/**
 *
 * @author Admin
 */
public class DispatchComplaint {
    private String complaintID;
    private String customerUsername;
    private String customerComplaint;
    private String customerContact;
    private String status;

    public DispatchComplaint(String complaintID, String customerUsername, String customerComplaint, String customerContact, String status) {
        this.complaintID = complaintID;
        this.customerUsername = customerUsername;
        this.customerComplaint = customerComplaint;
        this.customerContact = customerContact;
        this.status = status;
    }

    public String getComplaintID() {
        return complaintID;
    }

    public void setComplaintID(String complaintID) {
        this.complaintID = complaintID;
    }

    public String getCustomerUsername() {
        return customerUsername;
    }

    public void setCustomerUsername(String customerUsername) {
        this.customerUsername = customerUsername;
    }

    public String getCustomerComplaint() {
        return customerComplaint;
    }

    public void setCustomerComplaint(String customerComplaint) {
        this.customerComplaint = customerComplaint;
    }

    public String getCustomerContact() {
        return customerContact;
    }

    public void setCustomerContact(String customerContact) {
        this.customerContact = customerContact;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
