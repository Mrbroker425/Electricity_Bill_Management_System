/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity_bill_management_system;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Admin
 */
public class EmployeesFormController implements Initializable {

    @FXML
    private Label Payments;

    @FXML
    private Label unprocessedcomplaints;
    @FXML
    private Label Dispatched;
    @FXML
    private Label CheckinEmployee;

    private SystemData systemData;

    @FXML
    private TableView<DispatchComplaint> DispatchTableView;
    @FXML
    private TableColumn<DispatchComplaint, String> DispatchComplaintsno;
    @FXML
    private TableColumn<DispatchComplaint, String> DispatchCustomer;
    @FXML
    private TableColumn<DispatchComplaint, String> DispatchComplaints;
    @FXML
    private TableColumn<DispatchComplaint, String> DispatchContact;
    @FXML
    private TableColumn<DispatchComplaint, String> DispatchStatus;
    @FXML
    private ComboBox<String> DispatchList;

    private ObservableList<DispatchComplaint> dispatchComplaints;

    @FXML
    private AnchorPane EmployeeComplaintsPane;

    @FXML
    private Button EmployeeComplaintsbtn;

    @FXML
    private AnchorPane EmployeeDashboardPane;

    @FXML
    private Button EmployeeDashboardbtn;

    @FXML
    private AnchorPane EmployeeDispatchPane;

    @FXML
    private Button EmployeeDispatchbtn;

    @FXML
    private TableColumn<CustomerComplaint, String> Employee_Complaint;
    @FXML
    private TableColumn<CustomerComplaint, String> Employee_ComplaintDate;
    @FXML
    private TableColumn<CustomerComplaint, String> Employee_ComplaintIDno;
    @FXML
    private TableView<CustomerComplaint> Employee_ComplaintsHistorytableViews;
    @FXML
    private TableColumn<CustomerComplaint, String> Employee_CustomerUsername;
    @FXML
    private TableColumn<CustomerComplaint, String> Employee_Status;

    private int paymentsAmount = 4003; // Initial payments amount
    private int unprocessedComplaintsCount = 0; // Initial unprocessed complaints count
    private int dispatchedCount = 0; // Initial dispatched count

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize the SystemData instance
        systemData = new SystemData(1);

        // Set up the TableView columns for the Employee
        Employee_Complaint.setCellValueFactory(new PropertyValueFactory<>("customerComplaint"));
        Employee_ComplaintDate.setCellValueFactory(new PropertyValueFactory<>("customerComplaintDate"));
        Employee_ComplaintIDno.setCellValueFactory(new PropertyValueFactory<>("customerComplaintIDno"));
        Employee_CustomerUsername.setCellValueFactory(new PropertyValueFactory<>("customerUsername"));
        Employee_Status.setCellValueFactory(new PropertyValueFactory<>("customerStatus"));

        // Set up the TableView columns for the Dispatch
        DispatchComplaintsno.setCellValueFactory(new PropertyValueFactory<>("complaintID"));
        DispatchCustomer.setCellValueFactory(new PropertyValueFactory<>("customerUsername"));
        DispatchComplaints.setCellValueFactory(new PropertyValueFactory<>("customerComplaint"));
        DispatchContact.setCellValueFactory(new PropertyValueFactory<>("customerContact"));
        DispatchStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Initialize the dispatchComplaints list
        dispatchComplaints = FXCollections.observableArrayList();

        // Populate the DispatchTableView
        updateDispatchTableView();

        // Populate the DispatchList ComboBox
        DispatchList();

        // Set up the event handler for the DispatchList ComboBox
        DispatchList.setOnAction(this::handleDispatchStatusChange);

        // Populate the Employee_ComplaintsHistorytableViews
        updateEmployeeComplaintsTableView();

        // Update the labels
        updateLabels();
    }

    private void updateLabels() {
        // Update the Payments label
        Payments.setText("Payments: R " + paymentsAmount);

        // Update the unprocessedcomplaints label
        unprocessedcomplaints.setText("Unprocessed Complaints: " + unprocessedComplaintsCount);

        // Update the Dispatched label
        Dispatched.setText("Dispatched: " + dispatchedCount);
    }

    private void updateCounts(String status) {
        // Update the unprocessed complaints count
        if (!status.equalsIgnoreCase("Dispatched")) {
            unprocessedComplaintsCount++;
        } else {
            unprocessedComplaintsCount--;
            dispatchedCount++;
        }
    }

    @FXML
    private void switchEmployeeForms(ActionEvent event) {
        // First, hide all other panes
        hideAllEmployeePanes();

        // Check which button was clicked
        if (event.getSource() == EmployeeDashboardbtn) {
            // Disable the clicked button to prevent multiple clicks
            EmployeeDashboardbtn.setDisable(true);

            // Make the corresponding pane visible
            if (EmployeeDashboardPane != null) {
                EmployeeDashboardPane.setVisible(true);
            }

            // Enable other buttons as needed
            EmployeeDispatchbtn.setDisable(false);
            EmployeeComplaintsbtn.setDisable(false);
        } else if (event.getSource() == EmployeeDispatchbtn) {
            // Disable the clicked button to prevent multiple clicks
            EmployeeDispatchbtn.setDisable(true);

            // Make the corresponding pane visible
            if (EmployeeDispatchPane != null) {
                EmployeeDispatchPane.setVisible(true);
            }

            // Enable other buttons as needed
            EmployeeDashboardbtn.setDisable(false);
            EmployeeComplaintsbtn.setDisable(false);
        } else if (event.getSource() == EmployeeComplaintsbtn) {
            // Disable the clicked button to prevent multiple clicks
            EmployeeComplaintsbtn.setDisable(true);

            // Make the corresponding pane visible
            if (EmployeeComplaintsPane != null) {
                EmployeeComplaintsPane.setVisible(true);
            }

            // Enable other buttons as needed
            EmployeeDashboardbtn.setDisable(false);
            EmployeeDispatchbtn.setDisable(false);
        }
    }

    private void hideAllEmployeePanes() {
        // Hide all panes
        EmployeeDashboardbtn.setDisable(false);
        EmployeeDispatchbtn.setDisable(false);
        EmployeeComplaintsbtn.setDisable(false);

        EmployeeDashboardPane.setVisible(false);
        EmployeeDispatchPane.setVisible(false);
        EmployeeComplaintsPane.setVisible(false);
    }

    private void updateEmployeeComplaintsTableView() {
        ObservableList<CustomerComplaint> customerComplaints = systemData.getAllCustomerComplaints();
        Employee_ComplaintsHistorytableViews.setItems(customerComplaints);
    }

    private void DispatchList() {
        List<String> listR = new ArrayList<>();
        listR.add("Dispatched");
        listR.add("Call Unanswered");
        listR.add("Calling Soon");

        ObservableList<String> listData = FXCollections.observableArrayList(listR);
        DispatchList.setItems(listData);
    }

    private void updateDispatchTableView() {
        // Clear the existing data in the table
        dispatchComplaints.clear();

        // Retrieve the data from the database
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(
                "SELECT cc.complaint_id, c.username, cc.complaint, c.contact, cc.complaint_status "
                + "FROM CustomerComplaint cc "
                + "JOIN customers c ON cc.customer_username = c.username")) {
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String complaintID = String.valueOf(resultSet.getInt("complaint_id"));
                    String customerUsername = resultSet.getString("username");
                    String customerComplaint = resultSet.getString("complaint");
                    String customerContact = resultSet.getString("contact");
                    String status = resultSet.getString("complaint_status");

                    DispatchComplaint dispatchComplaint = new DispatchComplaint(complaintID, customerUsername, customerComplaint, customerContact, status);
                    dispatchComplaints.add(dispatchComplaint);

                    // Update the unprocessed complaints and dispatched counts
                    updateCounts(status);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }

        // Set the items of the TableView
        DispatchTableView.setItems(dispatchComplaints);

        // Update the labels
        updateLabels();
    }

    private void handleDispatchStatusChange(ActionEvent event) {
        DispatchComplaint selectedDispatchComplaint = DispatchTableView.getSelectionModel().getSelectedItem();
        if (selectedDispatchComplaint != null) {
            String newStatus = DispatchList.getSelectionModel().getSelectedItem();
            if (newStatus != null) {
                // Update the status in the database
                updateDispatchStatus(selectedDispatchComplaint.getComplaintID(), newStatus);
                selectedDispatchComplaint.setStatus(newStatus);
                DispatchTableView.refresh();

                // Update the unprocessed complaints and dispatched counts
                updateCounts(newStatus);
                updateLabels();
            } else {
                showErrorMessage("Please select a status to change the dispatch complaint.");
            }
        } else {
            showErrorMessage("Please select a dispatch complaint to change the status.");
        }
    }

    private void updateDispatchStatus(String complaintID, String newStatus) {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(
                "UPDATE CustomerComplaint SET complaint_status = ? WHERE complaint_id = ?")) {
            statement.setString(1, newStatus);
            statement.setString(2, complaintID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
