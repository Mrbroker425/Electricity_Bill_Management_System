package electricity_bill_management_system;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FXMLDocumentController implements Initializable {

    private AlertMessage alert = new AlertMessage();

    @FXML
    private AnchorPane EmployeeForm;
    @FXML
    private AnchorPane adminForm;
    @FXML
    private AnchorPane loginForm;

    @FXML
    private PasswordField CustomerConfirmPassword;
    @FXML
    private TextField CustomerContact;
    @FXML
    private AnchorPane CustomerForm;
    @FXML
    private PasswordField CustomerPassword;
    @FXML
    private Button CustomerSignUpbtn;
    @FXML
    private Hyperlink CustomerSigninhere;
    @FXML
    private TextField CustomerUsername;

    @FXML
    private TextField EmployeeConfirmPassword;
    @FXML
    private PasswordField EmployeePassword;
    @FXML
    private Button EmployeeSignUpbtn;
    @FXML
    private Hyperlink EmployeeSigninhere;
    @FXML
    private TextField EmployeeContact;
    @FXML
    private TextField EmployeeUsername;

    @FXML
    private PasswordField adminConfirmPassword;
    @FXML
    private TextField adminContact;
    @FXML
    private PasswordField adminPassword;
    @FXML
    private Button adminSignUpbtn;
    @FXML
    private Hyperlink adminSigninhere;
    @FXML
    private TextField adminUsername;
    @FXML
    private ComboBox<String> loginRole;

    @FXML
    private PasswordField loginPassword;

    @FXML
    private TextField loginUsername;
    @FXML
    private Button loginbtn;

    public void signInForm() {
        loginForm.setVisible(true);
        EmployeeForm.setVisible(false);
        adminForm.setVisible(false);
        CustomerForm.setVisible(false);
    }

    public void switchForm(ActionEvent event) {
        String selectedRole = loginRole.getSelectionModel().getSelectedItem();
        if (selectedRole == null) {
            alert.errorMessage("Please select your role and Press Sign in here if Already registered, if not please register with your selected role");
            return;
        }

        switch (selectedRole) {
            case "Employee":
                loginForm.setVisible(false);
                EmployeeForm.setVisible(true);
                adminForm.setVisible(false);
                CustomerForm.setVisible(false);
                break;
            case "Administrator":
                loginForm.setVisible(false);
                EmployeeForm.setVisible(false);
                adminForm.setVisible(true);
                CustomerForm.setVisible(false);
                break;
            case "Customer":
                loginForm.setVisible(false);
                EmployeeForm.setVisible(false);
                adminForm.setVisible(false);
                CustomerForm.setVisible(true);
                break;
            default:
                break;
        }
    }

    public void registerAdministrator() {
        if (adminUsername.getText().isEmpty() || adminPassword.getText().isEmpty()
                || adminConfirmPassword.getText().isEmpty() || adminContact.getText().isEmpty()) {
            alert.errorMessage("Please fill all blank fields");
        } else {
            try (Connection connect = Database.getConnection()) {
                String username = adminUsername.getText().trim();
                String password = adminPassword.getText();
                String confirmPassword = adminConfirmPassword.getText();
                String contact = adminContact.getText().trim();

                // Check if the number of administrators is less than 3
                int adminCount = getAdminCount(connect);
                if (adminCount >= 3) {
                    alert.errorMessage("Maximum number of administrators (3) has been reached.");
                    return;
                }

                if (!isUniqueField(connect, "administrators", "username", username)) {
                    alert.errorMessage(username + " is already exist");
                    return;
                }

                if (!isUniqueField(connect, "administrators", "contact", contact)) {
                    alert.errorMessage("The contact number " + contact + " is already registered.");
                    return;
                }

                if (!username.matches("\\d{5}")) {
                    alert.errorMessage("Invalid username format. Please enter your 5 uniquely identifiable valid Employee number");
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    alert.errorMessage("Password does not match.");
                    return;
                }

                if (password.length() < 8) {
                    alert.errorMessage("Invalid password, at least 8 characters needed");
                    return;
                }

                String insertData = "INSERT INTO administrators (username, contact, password, date_registered, role) "
                        + "VALUES(?,?,?,?,?)";

                java.sql.Date sqlDate = new java.sql.Date(new java.util.Date().getTime());

                try (PreparedStatement prepare = connect.prepareStatement(insertData)) {
                    prepare.setString(1, username);
                    prepare.setString(2, contact);
                    prepare.setString(3, password);
                    prepare.setDate(4, sqlDate);
                    prepare.setString(5, "Administrator");

                    prepare.executeUpdate();
                }

                alert.successMessage("Administrator registered successfully!");

                loginForm.setVisible(true);
                adminForm.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private int getAdminCount(Connection connection) {
        int count = 0;
        try (PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM administrators")) {
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    count = resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    private boolean isUniqueField(Connection connection, String table, String field, String value) {
        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + table + " WHERE " + field + " = ?")) {
            statement.setString(1, value);
            try (ResultSet resultSet = statement.executeQuery()) {
                return !resultSet.next(); // Returns true if resultSet is empty, meaning the field is unique
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Error occurred, return false as safety measure
        }
    }

    public void registerEmployee() {
        if (EmployeeUsername.getText().isEmpty() || EmployeePassword.getText().isEmpty()
                || EmployeeConfirmPassword.getText().isEmpty() || EmployeeContact.getText().isEmpty()) {
            alert.errorMessage("Please fill all blank fields");
        } else {
            try (Connection connect = Database.getConnection()) {
                String username = EmployeeUsername.getText().trim();
                String password = EmployeePassword.getText();
                String confirmPassword = EmployeeConfirmPassword.getText();
                String contact = EmployeeContact.getText().trim();

                if (!isUniqueField(connect, "employees", "username", username)) {
                    alert.errorMessage(username + " is already exist");
                    return;
                }

                if (!isUniqueField(connect, "employees", "contact", contact)) {
                    alert.errorMessage("The contact number " + contact + " is already registered.");
                    return;
                }

                if (!username.matches("\\d{5}")) {
                    alert.errorMessage("Invalid username format. Please enter your 5 uniquely identifiable valid Employee number");
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    alert.errorMessage("Password does not match.");
                    return;
                }

                if (password.length() < 8) {
                    alert.errorMessage("Invalid password, at least 8 characters needed");
                    return;
                }

                String insertData = "INSERT INTO employees (username, contact, password, role) "
                        + "VALUES(?,?,?,?)";

                try (PreparedStatement prepare = connect.prepareStatement(insertData)) {
                    prepare.setString(1, username);
                    prepare.setString(2, contact);
                    prepare.setString(3, password);
                    prepare.setString(4, "Employee");

                    prepare.executeUpdate();
                }

                alert.successMessage("Employee registered successfully!");

                loginForm.setVisible(true);
                EmployeeForm.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void registerCustomer() {
        if (CustomerUsername.getText().isEmpty() || CustomerPassword.getText().isEmpty()
                || CustomerConfirmPassword.getText().isEmpty() || CustomerContact.getText().isEmpty()) {
            alert.errorMessage("Please fill all blank fields");
        } else {
            try (Connection connect = Database.getConnection()) {
                String username = CustomerUsername.getText().trim();
                String password = CustomerPassword.getText();
                String confirmPassword = CustomerConfirmPassword.getText();
                String contact = CustomerContact.getText().trim();

                if (!isUniqueField(connect, "customers", "username", username)) {
                    alert.errorMessage(username + " is already exist");
                    return;
                }

                if (!isUniqueField(connect, "customers", "contact", contact)) {
                    alert.errorMessage("The contact number " + contact + " is already registered.");
                    return;
                }

                if (!isValidEmail(username)) {
                    alert.errorMessage("Invalid email format. Please enter a valid email address.");
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    alert.errorMessage("Password does not match.");
                    return;
                }

                if (password.length() < 8) {
                    alert.errorMessage("Invalid password, at least 8 characters needed");
                    return;
                }

                String insertData = "INSERT INTO customers (username, contact, password, role) "
                        + "VALUES(?,?,?,?)";

                try (PreparedStatement prepare = connect.prepareStatement(insertData)) {
                    prepare.setString(1, username);
                    prepare.setString(2, contact);
                    prepare.setString(3, password);
                    prepare.setString(4, "Customer");

                    prepare.executeUpdate();
                }

                alert.successMessage("Customer registered successfully!");

                loginForm.setVisible(true);
                CustomerForm.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    public void loginAccount() {
        if (loginUsername.getText().isEmpty() || loginPassword.getText().isEmpty()) {
            alert.errorMessage("Please fill all blank fields");
        } else {
            String selectedRole = loginRole.getSelectionModel().getSelectedItem();
            if (selectedRole == null) {
                alert.errorMessage("Please select your role and Press Sign in here if Already registered, if not please register with your selected role");
                return;
            }

            String tableName;
            switch (selectedRole) {
                case "Administrator":
                    tableName = "administrators";
                    break;
                case "Customer":
                    tableName = "customers";
                    break;
                case "Employee":
                    tableName = "employees";
                    break;
                default:
                    alert.errorMessage("Invalid Role");
                    return;
            }

            String selectData = "SELECT username, password, role FROM " + tableName + " WHERE username = ? AND password = ?";
            try (Connection connect = Database.getConnection(); PreparedStatement prepare = connect.prepareStatement(selectData)) {
                prepare.setString(1, loginUsername.getText());
                prepare.setString(2, loginPassword.getText());
                try (ResultSet result = prepare.executeQuery()) {
                    if (result.next()) {
                        String role = result.getString("role");
                        System.out.println(role); // You can remove this line if not needed
                        Thread.sleep(1000);
                        switch (role) {
                            case "Administrator":
                                loadAndShowForm("AdministratorForm.fxml", "Electricity Bill Management System | Admin Portal");
                                break;
                            case "Customer":
                                loadAndShowForm("Customer.fxml", "Electricity Bill Management System | Customer Portal");
                                break;
                            case "Employee":
                                loadAndShowForm("Employees.fxml", "Electricity Bill Management System | Employee Portal");
                                break;
                            default:
                                alert.errorMessage("Invalid Role");
                                break;
                        }
                    } else {
                        alert.errorMessage("Incorrect Username/Password");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

   private void loadAndShowForm(String fxmlFile, String title) {
    try {
        URL fxmlLocation = getClass().getResource(fxmlFile);
        if (fxmlLocation == null) {
            alert.errorMessage("FXML file not found: " + fxmlFile);
            return;
        }
        Parent root = FXMLLoader.load(fxmlLocation);
        Stage stage = new Stage();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.show();
        loginForm.getScene().getWindow().hide();
    } catch (IOException e) {
        e.printStackTrace();
    }
}


    private void StatusList() {
        ObservableList<String> listData = FXCollections.observableArrayList("Administrator", "Customer", "Employee");
        loginRole.setItems(listData);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        StatusList();

    }

}
