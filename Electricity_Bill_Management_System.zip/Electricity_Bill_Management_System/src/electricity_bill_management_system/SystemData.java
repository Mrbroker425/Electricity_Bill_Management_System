/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Admin
 */
package electricity_bill_management_system;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class SystemData {

    private static final String INSERT_COMPLAINT_QUERY = "INSERT INTO CustomerComplaint (customer_username, complaint_date, complaint, complaint_status) VALUES (?, ?, ?, ?)";
    private static final String SELECT_COMPLAINTS_QUERY = "SELECT c.username AS customer_username, cc.complaint_date, cc.complaint_id, cc.complaint_status, cc.complaint "
            + "FROM CustomerComplaint cc "
            + "JOIN customers c ON cc.customer_username = c.username "
            + "WHERE c.customer_id = ?";
    private static final String GET_CUSTOMER_USERNAME_QUERY = "SELECT username FROM customers WHERE customer_id = ?";
    private static final String UPDATE_COMPLAINT_STATUS_QUERY = "UPDATE CustomerComplaint SET complaint_status = ? WHERE complaint_id = ?";
    private static final String SELECT_ALL_COMPLAINTS_QUERY = "SELECT c.username AS customer_username, cc.complaint_date, cc.complaint_id, cc.complaint_status, cc.complaint "
            + "FROM CustomerComplaint cc "
            + "JOIN customers c ON cc.customer_username = c.username";
    private static final String INSERT_BILL_QUERY = "INSERT INTO billing (BillNo, Customer, DateGenerated, UnitsConsumed, Amount, DueDate, Status) VALUES (?, ?, ?, ?, ?, ?, ?)";

    private final ObservableList<CustomerComplaint> customerComplaints;
    private final ObservableList<Bill> allBills;
    private int loggedInCustomerId;

    public SystemData(int loggedInCustomerId) {
        this.loggedInCustomerId = loggedInCustomerId;
        this.customerComplaints = FXCollections.observableArrayList();
        this.allBills = FXCollections.observableArrayList();
        loadCustomerComplaints();
        loadAllBills();
    }

    private void loadCustomerComplaints() {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_COMPLAINTS_QUERY)) {
            statement.setInt(1, loggedInCustomerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                customerComplaints.clear(); // Clear the existing complaints
                while (resultSet.next()) {
                    String customerUsername = resultSet.getString("customer_username");
                    String complaintDate = resultSet.getDate("complaint_date").toLocalDate().toString();
                    String complaintID = String.valueOf(resultSet.getInt("complaint_id"));
                    String complaintStatus = resultSet.getString("complaint_status");
                    String complaint = resultSet.getString("complaint"); // Retrieve the complaint text
                    CustomerComplaint newComplaint = new CustomerComplaint(complaint, complaintDate, complaintID, customerUsername, complaintStatus);
                    customerComplaints.add(newComplaint);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    private void loadAllBills() {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement("SELECT * FROM billing")) {
            try (ResultSet resultSet = statement.executeQuery()) {
                allBills.clear(); // Clear the existing bills
                while (resultSet.next()) {
                    String billNo = resultSet.getString("BillNo");
                    String customer = resultSet.getString("Customer");
                    LocalDate billDate = resultSet.getDate("DateGenerated").toLocalDate();
                    int unitsConsumed = resultSet.getInt("UnitsConsumed");
                    double amount = resultSet.getDouble("Amount");
                    LocalDate dueDate = resultSet.getDate("DueDate").toLocalDate();
                    String status = resultSet.getString("Status");
                    Bill newBill = new Bill(billNo, customer, billDate, unitsConsumed, amount, dueDate, status);
                    allBills.add(newBill);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    public ObservableList<CustomerComplaint> getCustomerComplaints() {
        return customerComplaints;
    }

    public ObservableList<Bill> getAllBills() {
        return allBills;
    }

    public void addCustomerComplaint(String selectedComplaint) {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(INSERT_COMPLAINT_QUERY)) {
            LocalDate currentDate = LocalDate.now();
            statement.setString(1, getLoggedInCustomerUsername());
            statement.setDate(2, Date.valueOf(currentDate));
            statement.setString(3, selectedComplaint);
            statement.setString(4, "Open");

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                int lastInsertedComplaintID = getLastInsertedComplaintID(connection);
                CustomerComplaint newComplaint = new CustomerComplaint(selectedComplaint, currentDate.toString(), String.valueOf(lastInsertedComplaintID), getLoggedInCustomerUsername(), "Open");
                customerComplaints.add(newComplaint);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    private int getLastInsertedComplaintID(Connection connection) throws SQLException {
        String query = "SELECT LAST_INSERT_ID()";
        try (PreparedStatement statement = connection.prepareStatement(query); ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        }
        return -1;
    }

    public String getLoggedInCustomerUsername() {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(GET_CUSTOMER_USERNAME_QUERY)) {
            statement.setInt(1, loggedInCustomerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("username");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
        return "";
    }

    public ObservableList<String> getNewComplaintOptions() {
        return FXCollections.observableArrayList("Billing issue", "Password Update", "Username Update", "Contact Update", "Previous Complaint Not Processed", "Bill Generated Late", "Bill Not Correct", "Transaction Not Processed", "Product defect", "Service complaint", "Other");
    }

    public void updateComplaintStatus(String complaintId, String newStatus) {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_COMPLAINT_STATUS_QUERY)) {
            statement.setString(1, newStatus);
            statement.setString(2, complaintId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    public ObservableList<CustomerComplaint> getAllCustomerComplaints() {
        ObservableList<CustomerComplaint> allComplaints = FXCollections.observableArrayList();
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_ALL_COMPLAINTS_QUERY); ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String customerUsername = resultSet.getString("customer_username");
                String complaintDate = resultSet.getDate("complaint_date").toLocalDate().toString();
                String complaintID = String.valueOf(resultSet.getInt("complaint_id"));
                String complaintStatus = resultSet.getString("complaint_status");
                String complaint = resultSet.getString("complaint");
                CustomerComplaint newComplaint = new CustomerComplaint(complaint, complaintDate, complaintID, customerUsername, complaintStatus);
                allComplaints.add(newComplaint);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
        return allComplaints;
    }

    public void saveBill(Bill bill) {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(INSERT_BILL_QUERY)) {
            statement.setString(1, bill.getBillNo());
            statement.setString(2, bill.getCustomer());
            statement.setDate(3, Date.valueOf(bill.getBillDate()));
            statement.setInt(4, bill.getUnitsConsumed());
            statement.setDouble(5, bill.getAmount());
            statement.setDate(6, Date.valueOf(bill.getDueDate()));
            statement.setString(7, bill.getStatus());

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                // Bill saved successfully
            } else {
                // Handle the case where the bill was not saved
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }
    private static final String GET_LAST_BILL_NUMBER_QUERY = "SELECT MAX(BillNo) AS last_bill_number FROM billing";

    public String getLastBillNumber() {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(GET_LAST_BILL_NUMBER_QUERY)) {
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String lastBillNumber = resultSet.getString("last_bill_number");
                    if (lastBillNumber == null) {
                        return "B000001"; // Default value if there are no bills
                    } else {
                        int lastNumber = Integer.parseInt(lastBillNumber.substring(1));
                        return String.format("B%06d", lastNumber + 1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
        return "B000001";
    }

    public String generateBillNumber() {
        String lastBillNumber = getLastBillNumber();
        int lastNumber = 1;
        if (lastBillNumber != null && !lastBillNumber.isEmpty()) {
            lastNumber = Integer.parseInt(lastBillNumber.substring(1)) + 1;
        }
        return String.format("B%06d", lastNumber);
    }

    private static final String SELECT_CUSTOMER_BILLS_QUERY = "SELECT BillNo, Customer, DateGenerated, UnitsConsumed, Amount, DueDate, Status "
            + "FROM billing "
            + "WHERE Customer = ?";

    public ObservableList<Bill> getCustomerBills(String customerUsername) {
        ObservableList<Bill> customerBills = FXCollections.observableArrayList();
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_CUSTOMER_BILLS_QUERY)) {
            statement.setString(1, customerUsername);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String billNo = resultSet.getString("BillNo");
                    String customer = resultSet.getString("Customer");
                    LocalDate billDate = resultSet.getDate("DateGenerated").toLocalDate();
                    int unitsConsumed = resultSet.getInt("UnitsConsumed");
                    double amount = resultSet.getDouble("Amount");
                    LocalDate dueDate = resultSet.getDate("DueDate").toLocalDate();
                    String status = resultSet.getString("Status");
                    Bill bill = new Bill(billNo, customer, billDate, unitsConsumed, amount, dueDate, status);
                    customerBills.add(bill);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
        return customerBills;
    }

    private static final String UPDATE_BILL_STATUS_QUERY = "UPDATE billing SET Status = ? WHERE BillNo = ?";

    public void updateBillStatus(String billNo, String newStatus) {
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_BILL_STATUS_QUERY)) {
            statement.setString(1, newStatus);
            statement.setString(2, billNo);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    private static final String SELECT_ALL_CUSTOMERS_QUERY = "SELECT * FROM customers";

    public ObservableList<Customer> getAllCustomers() {
        ObservableList<Customer> customers = FXCollections.observableArrayList();
        try (Connection connection = Database.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_ALL_CUSTOMERS_QUERY); ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int customer_id = resultSet.getInt("customer_id");
                String username = resultSet.getString("username");
                String contact = resultSet.getString("contact");
                String password = resultSet.getString("password");
                String role = resultSet.getString("role");
                Customer customer = new Customer(customer_id, username, contact, password, role);
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }

}
